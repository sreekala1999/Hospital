from django.contrib import admin
from Hospitalapp.models import Department,Doctors,Booking1

# Register your models here.
admin.site.register(Department)
admin.site.register(Doctors)
admin.site.register(Booking1)

